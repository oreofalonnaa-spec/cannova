# CANNOVA : plan de campagne (4 semaines)

## 1. Objectif et cible
- **Objectif** : faire connaître le site, générer des visites qualifiées et des messages WhatsApp ou Telegram à l'équipe.
- **Cible** : adultes (18 ans et plus), France et Europe, qui cherchent des fleurs et résines CBD livrées vite et discrètement.
- **Promesses à utiliser** (et seulement celles-là) : sélection USA, livraison en quelques heures *selon la zone*, livraison gratuite dès 49 €, emballage discret, boîtes collector au choix (Cali, Atlas, Angel, Muzo), code de réduction.

## 2. Règles de conformité (à lire avant de publier quoi que ce soit)
1. **Seuls des produits dont le taux de THC est inférieur à 0,3 %**, avec analyse de laboratoire du lot, peuvent être promus. Garde les certificats.
2. **Aucune promesse d'effet ni de bénéfice santé** : pas de « détente », « sommeil », « anti-stress », « puissant », « euphorie ». Décris l'aspect, l'arôme, la livraison, l'emballage.
3. **Aucune image de consommation** (fumée, joint, bang, yeux rouges) et **pas de personnage protégé**. Les visuels fournis n'utilisent que tes personnages originaux.
4. **Mention « Réservé aux adultes (18+) »** sur chaque visuel, et ciblage adulte quand l'outil le permet.
5. **Publicité payante** : Meta (Facebook, Instagram), Google, TikTok et YouTube interdisent ou restreignent très fortement la publicité pour le CBD et le cannabis, et ferment les comptes. En France, la loi interdit aussi la publicité en faveur du cannabis, et le CBD est surveillé de près. **Ne lance pas de publicité payante sans avis d'un juriste.** Cette campagne repose donc sur des canaux organiques.
6. **Messages directs et listes de diffusion** : uniquement avec l'accord de la personne (WhatsApp, Telegram, e-mail).
7. Les extraits et noms de variétés des fournisseurs ne doivent pas être copiés tels quels s'ils contiennent des promesses d'effet.

## 3. Canaux (du plus au moins prioritaire)
| Canal | Usage | Remarque |
|---|---|---|
| **Instagram (organique)** | publications, stories, reels sans produit consommé | profil « boutique », lien en bio avec UTM |
| **Canal Telegram** | annonces, nouveautés, code du moment | l'abonné s'inscrit lui-même |
| **WhatsApp (statut et liste de diffusion)** | nouveautés, rappels de livraison gratuite | opt-in obligatoire |
| **Distributeurs partenaires (+200)** | affichette ou flyer avec QR code | mention 18+ |
| **Bouche-à-oreille et parrainage** | un code par parrain, créé dans l'espace admin | voir semaine 3 |
| **Contenu web (blog)** | articles informatifs sur la législation et la lecture d'une étiquette | sans allégation santé |

## 4. Liens à utiliser (pour mesurer chaque canal dans ton tableau de bord)
- Instagram : `https://cannova.vercel.app/?utm_source=instagram`
- Telegram : `https://cannova.vercel.app/?utm_source=telegram`
- WhatsApp : `https://cannova.vercel.app/?utm_source=whatsapp`
- Flyers et QR code : `https://cannova.vercel.app/?utm_source=flyer`
- Distributeurs : `https://cannova.vercel.app/?utm_source=distributeur`
Remplace `cannova.vercel.app` par ton nom de domaine quand tu en auras un.

## 5. Calendrier
**Semaine 1 : lancement**
- Lundi : publication `01-annonce-selection-usa` (texte A).
- Mercredi : story `04-story-code-reduction` + lien.
- Vendredi : publication `02-livraison-gratuite` (texte B).
- Chaque jour : une réponse à chaque commentaire ou message dans l'heure.

**Semaine 2 : confiance**
- Publication `03-choisis-ta-boite` (texte C) : montre les 4 styles de boîtes.
- Stories : coulisses de l'emballage discret (colis neutre, boîte collector), sans produit visible.
- Crée le canal Telegram et annonce-le en bio et en story.

**Semaine 3 : parrainage**
- Crée dans l'espace admin un code par partenaire ou parrain (par exemple `ami-karim`, 10 %).
- Message : « Un code pour toi, un code pour ton ami ».
- Dépose les flyers chez 5 distributeurs.

**Semaine 4 : bilan et relance**
- Lis le tableau de bord : quelle source amène le plus de personnes qui cliquent sur « finaliser » ?
- Double ce qui marche, coupe le reste.
- Relance : nouveau produit, nouveau code limité dans le temps (date d'expiration).

## 6. Textes prêts à publier (conformes)
**A. Annonce**
> Nouvelle sélection USA chez CANNOVA 🇺🇸 Fleurs et résines CBD, livrées en quelques heures* dans un colis 100 % discret. Livraison gratuite dès 49 €. Lien en bio. *Selon la zone. Réservé aux adultes (18+).

**B. Livraison**
> Livraison gratuite dès 49 € 📦 Emballage discret, boîte collector au choix. Commande ta sélection sur le site, puis finalise avec notre équipe sur WhatsApp ou Telegram. Réservé aux adultes (18+).

**C. Boîtes**
> Cali, Atlas, Angel ou Muzo : à toi de choisir le style de ta boîte au moment de valider ta commande. Laquelle est la tienne ? 👇 Réservé aux adultes (18+).

**Message à un distributeur**
> Bonjour, nous lançons une affichette CANNOVA (réservée aux adultes) avec un QR code et un code de réduction pour vos clients. Je vous envoie le visuel ?

**Réponse type à une question sur les effets**
> Nous ne pouvons pas donner d'indications sur des effets. Pour toute question de santé, parle à un professionnel de santé.

## 7. Mesure
Dans `/admin` : visites, visiteurs uniques, ajouts au panier, clics sur « finaliser », clics WhatsApp et Telegram, demandes spéciales, sources de trafic et usages de chaque code.
- Regarde surtout : **visites, puis clics sur « finaliser », puis messages à l'équipe**.
- Un taux visite vers message de 2 à 5 % est un bon départ pour un site neuf avec du trafic froid. Pour du trafic chaud (clients existants, partenaires), il peut être bien plus élevé. Je ne peux pas garantir de résultat.

## 8. Budget
- **0 €** pour démarrer (tout est organique).
- Options : un illustrateur pour des visuels supplémentaires, des échantillons ou goodies pour les distributeurs, un nom de domaine (environ 10 à 15 € par an).

## 9. Checklist avant chaque publication
- [ ] « Réservé aux adultes (18+) » visible.
- [ ] Aucune promesse d'effet ni de santé.
- [ ] Aucune image de consommation ni personnage protégé.
- [ ] Lien avec le bon `utm_source`.
- [ ] Les produits cités ont leur analyse de laboratoire.
