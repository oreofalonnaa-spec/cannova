# CANNOVA : le site de A à Z (version 2)

## 0. Ce qui contient ce dossier

```
cannova-project/
├── index.html                  <- le site (HTML + CSS + JavaScript)
├── README.md                   <- ce guide
└── images/                     <- TOUTES les photos produit
    ├── fleurs-usa/
    │   └── cali-gelato/        <- un dossier par produit (nom = "slug" du produit)
    │       ├── carte.jpg       <- photo de la carte (liste des produits)
    │       └── detail.jpg      <- photo de la fiche produit
    ├── resine-usa/boom-lunaire/carte.jpg + detail.jpg
    ├── fleurs-maroc/liberty-nano-9/carte.jpg + detail.jpg
    ├── fleurs-venezuela/  fleurs-colombie/  resine-maroc/
    ├── resine-venezuela/  resine-colombie/   (vides, prêts à recevoir tes photos)
index-autonome.html             <- version "fichier unique" (photos intégrées)
```

Deux façons de publier :
- **Dossier complet** (`index.html` + `images/`) : à privilégier, léger et facile à modifier.
- **Fichier unique** `index-autonome.html` : toutes les photos y sont intégrées. À renommer `index.html` si tu ne veux envoyer qu'un seul fichier. Les images s'affichent forcément.

## 1. Comment le site retrouve les photos (important)

Pour chaque produit, le site cherche tout seul :

```
images/<categorie>-<pays>/<slug>/carte.jpg
images/<categorie>-<pays>/<slug>/detail.jpg
```

où `<categorie>` = `fleurs` ou `resine`, `<pays>` = `usa`, `maroc`, `venezuela` ou `colombie`, et `<slug>` = le nom technique du produit écrit dans `index.html` (`slug:'cali-gelato'`).

Règles pour que ça marche sur Vercel :
1. Les noms de dossiers et de fichiers sont **en minuscules, sans accent, sans espace**, et l'extension est `.jpg` (pas `.JPG`, pas `.jpeg`, pas `.png`). Vercel fait la différence entre majuscules et minuscules.
2. Le dossier `images` doit être **à côté** de `index.html`, à la racine du projet.
3. Si une photo est introuvable, le site affiche une image de secours « Photo à venir » au lieu d'une image cassée.

### Ajouter un produit
1. Dans `index.html`, cherche `var CAT=` et ajoute le produit dans la bonne clé (`fleurs-usa`, `resine-maroc`, etc.) :
```js
CAT['resine-maroc']=[{
  slug:'atlas-gold',                     // nom technique du produit, sans accent
  name:'Atlas Gold',
  desc:'À partir de 12,00 €',
  text:'Description (facultatif)',
  info:[['Catégorie','Extrait'],['Origine','Maroc']],
  prices:[[1,12],[5,55],[10,100]]        // [grammes, prix total en €]
}];
```
2. Crée le dossier `images/resine-maroc/atlas-gold/` et dépose-y `carte.jpg` et `detail.jpg` (800 x 800 px conseillé, moins de 300 Ko).
3. Republie (voir plus bas).

## 2. Ce qui a changé dans la version 2
- **Photos** : chemins automatiques par produit, image de secours, version fichier unique.
- **Mobile et tablette** : les boîtes 3D s'adaptent à la largeur de l'écran (elles débordaient avant), nouvelles règles pour téléphones, petits téléphones et tablettes, cases plus compactes, boutons pleine largeur sur petit écran.
- **Logos WhatsApp et Telegram** : ils ne chevauchent plus les textes (le logo est en haut de la case, le texte en bas).
- **Telegram** : le lien est maintenant `https://t.me/cannovc`. Le message est copié dans le presse-papiers au clic et le client le colle dans la conversation. WhatsApp reste pré-rempli.

## 3. Modifier le site
| Quoi | Où chercher dans index.html |
|---|---|
| WhatsApp et Telegram | `TEAM={wa:'33646595261',tg:'cannovc'}` |
| Produits et prix | `var CAT=` |
| Livraison gratuite dès 49 € | chercher `49` |
| Couleurs | `:root{--bg, --lime, --n2, --n3, --n4, --holo}` |
| FAQ, étapes | `id="faq"` et `id="fonctionne"` |

## 4. Republier sur Vercel après une modification

**Si le site est relié à GitHub (le plus courant) :**
1. Va sur ton dépôt GitHub.
2. Ouvre le fichier à remplacer, ou clique sur Add file puis Upload files, et dépose les nouveaux fichiers **avec leurs dossiers** (glisse le dossier `images` en entier). Si un fichier existe déjà, il est remplacé.
3. Clique sur **Commit changes**.
4. Vercel republie tout seul en 30 à 60 secondes. Vérifie dans l'onglet **Deployments** du projet que le dernier déploiement est « Ready ».

**Si tu as déployé en ligne de commande :** ouvre un terminal dans le dossier du site et tape `npx vercel --prod`.

**Si les images ne s'affichent toujours pas :**
1. Ouvre le site, ajoute `/images/fleurs-usa/cali-gelato/carte.jpg` à la fin de l'adresse. Si tu vois la photo, le dossier est bon. Sinon, le dossier `images` n'a pas été envoyé ou il est au mauvais endroit.
2. Regarde sur GitHub : le dossier `images` doit être au même niveau que `index.html`.
3. Vérifie les noms (minuscules, `.jpg`).
4. Recharge sans cache : Ctrl+Maj+R sur ordinateur, ou ouvre le site en navigation privée.
5. En dernier recours, publie `index-autonome.html` (renommé `index.html`).

## 5. Conformité : à faire absolument
- **THC** : en France et dans la plupart des pays d'Europe, un produit CBD légal doit contenir moins de 0,3 % de THC. Garde l'analyse de laboratoire de chaque lot et affiche-la sur les fiches.
- **Pas de promesses** d'effet, de puissance, ni de mention médicale. Pas de photos de consommation.
- **Avis clients** : uniquement de vrais avis, avec l'accord des clients. Les faux avis sont interdits dans l'Union européenne.
- **Images** : n'utilise que des images dont tu détiens les droits.
- Ajoute les mentions légales, CGV et la politique de confidentialité (les liens du pied de page sont vides).
- Vérifie que ton hébergeur accepte les boutiques de CBD, et le plan nécessaire pour un usage commercial.

## 6. Le prompt complet

Copie ce texte dans l'outil de ton choix (Claude, un éditeur de code assisté, etc.) pour reconstruire le site. Il contient toutes les décisions de design.

```
Crée un site e-commerce one-page en un seul fichier HTML (CSS et JS inclus, aucune compilation) pour CANNOVA, une boutique de CBD (fleurs et résines) de 4 origines : USA, Maroc, Venezuela, Colombie. Texte en français, mobile en priorité.

IDENTITÉ VISUELLE : "Aurore holographique", futuriste, sombre.
- Fond quasi noir-vert (#030807), texte #eefcf6, accent citron #c6ff3d, turquoise #19e6d2, violet #9a5bff, rose #ff4bd8.
- Dégradé holographique : linear-gradient(100deg,#7cff6b,#19e6d2 30%,#9a5bff 62%,#ff4bd8) pour boutons (animés), barre de progression de scroll et gros chiffres.
- Polices Google : Anton (titres, majuscules) et Space Grotesk (texte).
- Cartes en verre dépoli (backdrop-filter), bordures blanches fines, lueurs néon, boutons arrondis.

FOND 3D ANIMÉ (three.js r128 depuis cdnjs, canvas fixe en arrière-plan) :
- Un plan shader plein écran (bruit fbm) qui forme une fumée d'aurore émeraude, turquoise, violet, rose. Les couleurs changent avec le scroll et la souris.
- 24 feuilles de chanvre 3D extrudées (7 folioles), métalliques, néon, qui tournent et flottent ; 600 particules additives.
- Caméra en parallaxe (scroll + souris). 14 feuilles sur mobile. Animation arrêtée si prefers-reduced-motion.

EN-TÊTE : bandeau défilant "Livraison gratuite dès 49 € + Emballage discret", logo CANNOVA, menu (Boutique, Origines, Distributeurs, Livraison, Boîtes), bouton "Panier (n)" qui compte les articles. Sur mobile, le menu passe sous l'en-tête en ligne défilante.

VÉRIFICATION D'ÂGE : écran plein écran "Tu as 18 ans ou plus ?" (Oui / Non), mémorisé en sessionStorage.

ACCUEIL :
1. Hero : une arche (border-radius 999px 999px 0 0) avec dégradé conique sombre et une feuille de chanvre en ligne ; mots géants "FLEURS" et "RÉSINE" (RÉSINE en contour citron) ; deux pastilles ("Les meilleures fleurs CBD" / "La résine CBD top qualité") ; un texte d'accroche dans un cadre à bordure holographique ; boutons "Découvrir la sélection →" (vers #boutique) ; indicateur "Descends ↓". Dans les 4 angles, 4 personnages originaux animés (SVG en ligne, style sticker, contour blanc via filtre feMorphology) : astronaute qui salue, chat chill avec casque audio et notes de musique, professeur à tête d'ampoule avec fiole, alien gélatineux à yeux sur tiges. Leurs pupilles suivent le pointeur, ils réagissent au survol et sautent au clic.
2. Deux rubans croisés qui défilent : citron (USA + Maroc + Venezuela + Colombie) et noir (Sélection directe + 4 origines + ...).
3. Bande d'engagements : +200 distributeurs en Europe / Livraison en quelques heures (selon la zone) / 100 % discret / Dès 49 €.
4. "À la une" : cartes des produits.
5. "Commander en 3 étapes" : Choisis, Confirme (WhatsApp ou Telegram), Reçois.
6. FAQ en <details> : délais, discrétion, commande et paiement, livraison gratuite, origines, âge minimum.
7. "4 origines. Zéro compromis."
8. "Une boîte par pays" : 4 pots ronds (fleurs) et 4 boîtes plates (résine) en 3D CSS, qui tournent seuls et se manipulent au doigt.
9. "+200 distributeurs" et "En quelques heures." Pied de page légal (18+, aucune allégation médicale).

BOÎTES 3D (CSS 3D, faces construites en JavaScript avec des SVG en data URI) :
- Pot rond pour les fleurs : corps cylindrique de 36 facettes avec étiquette enroulée, couvercle noir, dessus décoré. Ombrage dynamique par facette.
- Boîte plate rectangulaire pour la résine : 6 faces, design lunaire (ciel étoilé, grosse lune à cratères, orbite en pointillés, nom du pays).
- Un univers par pays, avec une créature féroce sur le couvercle du pot : USA "CALI" (crâne en flammes, synthwave rose/violet), Maroc "ATLAS" (lion, crinière en étoile, or et vert), Venezuela "ANGEL" (aigle et éclairs, jaune/bleu/rouge), Colombie "MUZO" (masque en losange, cristaux d'émeraude). Slogans sur les étiquettes : NO FEAR, ROAR, STORM, RISE.

PARCOURS BOUTIQUE (routage par hash, sans framework) :
- #boutique : 3 grandes cases : Fleurs, Résine, et "Demande spéciale" (emoji 🎭 qui se balance, pleine largeur).
- #fleurs ou #resine : 4 cases pays (USA, Maroc, Venezuela, Colombie).
- #fleurs-usa : catalogue du couple catégorie + pays (cartes produit, image fond blanc en mix-blend multiply).
- #fleurs-usa-cali-gelato : fiche produit : photo, description, liste d'infos, choix du format (cases avec prix total et prix/g, dégressif), total, bouton "Ajouter au panier" (fixé en bas sur mobile), et la boîte 3D du pays.
- Fil d'Ariane sur chaque étape. Fiches produit : seules les données déclarées dans un objet CAT sont affichées.

PANIER ET COMMANDE :
- #panier : liste avec quantités (− + supprimer), total, barre de progression vers la livraison gratuite (49 €), aperçu des boîtes 3D du colis, boutons "Valider ma commande" et "Continuer mes achats". Panier vide : seulement "Panier vide". Panier conservé en sessionStorage.
- #commande : formulaire adresse (nom, téléphone, adresse, code postal, ville, pays, infos livreur), attributs autocomplete pour le remplissage automatique du navigateur, pays détecté par la langue/fuseau de l'appareil, indicatif téléphonique automatique, 30 pays d'Europe.
- #finaliser : deux grandes cases WhatsApp (logo vert) et Telegram (logo bleu), avec récapitulatif. Le message est pré-rempli : "Voici mon panier :" + produits, grammes, prix, total + nom, adresse, téléphone. WhatsApp : https://wa.me/NUMERO?text=... ; Telegram : https://t.me/PSEUDO?text=... et copie du message dans le presse-papiers.
- #demande : mêmes deux boutons avec le message "J'aimerais faire une demande spéciale."

CONTRAINTES : aucun faux avis ni faux compteur, aucune promesse d'effet, aucune image protégée, taux de THC et analyses de laboratoire à afficher sur chaque fiche.
```
